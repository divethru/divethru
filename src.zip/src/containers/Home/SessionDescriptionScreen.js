import React, { Component } from 'react';
import PropTypes from 'prop-types';
import {
  View,
  Text,
  StatusBar,
  TouchableOpacity,
  Image,
  ImageBackground,
  ScrollView,
} from 'react-native';
import styles from '../../styles/sessionDescription';
import IC_WHITE_CLOSE from '../../assets/images/ic_close.png';
import sessionDescBg from '../../assets/images/SessionDescBg.png';

class SessionDescriptionScreen extends Component {
  static navigationOptions = () => ({
    header: null,
    tabBarVisible: false,
  });

  constructor(props) {
    super(props);
    this.state = {
      loading: false,
    };
  }

  componentDidMount() {
    StatusBar.setHidden(false);
    const { params } = this.props.navigation.state;
    const sessionData = params ? params.sessionData : undefined;

    // eslint-disable-next-line react/no-did-mount-set-state
    this.setState({
      title: sessionData.title,
      sessionDesc: sessionData.sessionDesc,
      sessionName: sessionData.sessionName,
    });
  }

  componentWillUnmount() {
    StatusBar.setHidden(true);
  }

  render() {
    return (
      <View style={styles.container}>
        <ScrollView>
          <StatusBar
            translucent
            backgroundColor="rgba(0, 0, 0, 0.010)"
            animated
            hidden={false}
          />
          <View style={styles.container}>
            <TouchableOpacity onPress={() => { this.props.navigation.goBack(); }}>
              <Image
                style={styles.closeIcon}
                source={IC_WHITE_CLOSE}
              />
            </TouchableOpacity>

            <View style={styles.introContainer}>
              <ImageBackground
                source={sessionDescBg}
                style={styles.backImageOfIntroContainer}
              >
                <Text style={styles.dayText}>{this.state.sessionName}</Text>
              </ImageBackground>
            </View>
          </View>

          <View style={styles.descContainer}>
            <Text style={styles.subText}>{this.state.title}</Text>

            <Text style={styles.descText}>{this.state.sessionDesc}</Text>

            {/* <Button
              primary
              title=""
              text="D I V E  T H R U"
              onPress={() => { this.props.navigation.goBack(); }}
              style={buttonStyles}
            /> */}
          </View>
        </ScrollView>
      </View>
    );
  }
}

SessionDescriptionScreen.propTypes = {
  navigation: PropTypes.object.isRequired,
};

export default SessionDescriptionScreen;
