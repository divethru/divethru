# Handoff: Balay at Santa Fe — Booking, Revenue & Expense Tracker

## Overview
An internal tool for Balay at Santa Fe (a cabin rental property) to manage room bookings, room revenue, miscellaneous revenue (land tours, massage, food, motor rental), and expenses (per-transaction and fixed monthly), with role-based access for Admin and Staff users. Property units: Cabin 1, Cabin 2, Cabin 3, Cabin 4, Exclusive A (Cabin 1+2), Exclusive B (Cabin 3+4), Full Exclusive (all 4), and Exclusive C (a separate cabin with loft).

## About the Design Files
The bundled file (`Booking Revenue Expense Tracker.dc.html`) is a **design/functional reference built as a single-file HTML prototype**. It currently persists all data to the browser's `localStorage` — there is no real backend, database, or multi-user support. It is not production code to copy directly. The task is to **rebuild this as a real web application** (a Next.js app is recommended given the target deployment is Vercel) backed by a real database, deployed on Vercel.

## Fidelity
**High-fidelity.** The prototype reflects final layout, copy, colors, typography, and interaction behavior. Recreate the UI closely, using a proper design system/component library (e.g. Tailwind + shadcn/ui, or a CSS setup matching the tokens below) rather than inline styles.

## Recommended stack
- **Framework**: Next.js (App Router) — pairs natively with Vercel.
- **Database**: Vercel Postgres, Neon, or Supabase Postgres. Use an ORM (Prisma or Drizzle).
- **Auth**: Replace the current plaintext-password localStorage login with real hashed-password auth (e.g. Auth.js/NextAuth with credentials provider, or Supabase Auth). Sessions should be server-verified, not just a session id in localStorage.
- **Image uploads**: The prototype has drag-and-drop photo slots for expenses (`<image-slot>` placeholders) — replace with real file upload to Vercel Blob or S3.

## Roles & Permissions
Two roles: **Admin** and **Staff**.

| Capability | Admin | Staff |
|---|---|---|
| Dashboard page | ✅ | ❌ (hidden from nav and blocked directly) |
| Reports page | ✅ | ❌ |
| Revenue Tracker page | ✅ | ❌ |
| Booking Calendar page | ✅ | ✅ |
| Expense Tracker page | ✅ | ✅ (view/add only their own expenses; Fixed Monthly Expenses section hidden) |
| Misc Revenue page | ✅ | ✅ |
| Admin Panel (manage staff accounts) | ✅ | ❌ |
| Add entries (bookings, expenses, misc revenue) | ✅ | ✅ |
| Edit entries | ✅ | Only if their account has "Can edit" enabled (set per-staff by Admin in Admin Panel) |
| Delete entries (expenses, fixed expenses, misc revenue) | ✅ only | ❌ never (no delete UI for Staff) |
| Change an expense's Exclusive tag (A/B/C/General) inline | ✅ only | ❌ (view-only tag badge) |
| Edit / view exclusive-tag on expense's Exclusive tag inline | ✅ | ❌ |

Each staff user has: `name`, `username`, `password`, `role` (admin/staff), `canEdit` (boolean). Default seed admin: username `admin`, password `admin123` (must be replaced with a real hashed credential in production, and this default removed).

Staff on the Expense Tracker page only see expense rows they personally created (`createdBy` matches their name); Admin sees all.

## Data Model

### User
- id, name, username, password (hash in production), role ('admin' | 'staff'), canEdit (boolean)

### Booking
- id, unit(s) booked (one or more of: Cabin 1, Cabin 2, Cabin 3, Cabin 4, Exclusive A, Exclusive B, Full Exclusive, Exclusive C)
- source (e.g. Direct, Airbnb, Agoda, Booking.com, etc. — a select)
- package (a select, "None" default)
- checkIn (date), checkOut (date), nights (derived)
- per-night price breakdown and total (weekend/PH-holiday nights priced differently — a "Weekend / PH holiday" flag/highlight exists on the calendar)
- guestName, contact
- pax, deposit, balance
- promo (boolean "free night" promo) + freeNightDate (selectable when multiple nights qualify)
- notes
- status: normal | no_show | cancelled_refund
- createdBy (user name who created it)

### Expense (per-transaction)
- id, photo (image), item, category (select), cost, quantity, date
- exclusiveTag: 'A' | 'B' | 'C' | 'General' (only Admin can change this after creation)
- notes, createdBy

### FixedExpense (monthly recurring, e.g. Starlink, salaries, SSS)
- id, name, amount (monthly), exclusiveTag: 'A' | 'B' | 'C' | 'General'
- history: array of {amount, from: 'YYYY-MM'} — supports amount changing over time while preserving past months' figures
- **Charging logic**: if tagged A/B/C, the full monthly amount charges to that Exclusive's expense total. If tagged 'General' (default), the amount is split evenly ÷3 across Exclusive A, B, and C.

### MiscRevenue
- id, type (Land Tour | Massage | Food | Motor Rental), guest (either linked to an existing Booking's guest, or a manually-typed guest name), amount, date, notes, createdBy
- Editable and deletable by Admin; editable (not deletable) by Staff.

## Business logic — expense/revenue rollups
For a given month and a given Exclusive group (A/B/C or "All"):
- `expensesByGroup`: direct (per-transaction) expenses summed by their `exclusiveTag`, including a 'General' bucket.
- `fixedExpensesByGroup`: fixed expenses summed by their `exclusiveTag` for that month (respecting amount `history`), including a 'General' bucket.
- Total expense charged to group K (A/B/C) = direct[K] + (direct.General ÷ 3) + fixed[K] + (fixed.General ÷ 3).
- Total expense for "All" = sum of all direct expenses (A+B+C+General) + sum of all fixed expenses (no division, since nothing is double counted across groups at the "All" level).
- Room revenue by group comes from bookings' unit/date overlap with the selected month, priced by their stored total (split across nights when a stay spans months — check the "All bookings"/"Bookings this month" table logic in the prototype for the precise month-overlap and pro-ration rule).
- Net = revenue (room + optionally misc) − total expenses.

## Screens / Pages

### 1. Login
Centered card: logo, "Internal Tracker" subtitle, username/password fields, error message, Sign In button.

### 2. Dashboard (Admin only)
- Month + Exclusive filters.
- Summary card: bookings count, room revenue, misc revenue, expenses, net (for selected period).
- Occupancy rate by month — bar chart (12 months).
- Cancellations & no-shows by month — grouped bar chart (cancelled vs no-show, 2 series).
- Monthly breakdown table: month, bookings, revenue, misc revenue, expenses, net.

### 3. Reports (Admin only)
- Year/Month/Exclusive filters, "Include Misc Revenue" checkbox, Download CSV, Print/Save as PDF.
- Read-only booking calendar grid for the period.
- Revenue card (room + misc + total) and Expenses card (total + fixed-cost share) side by side.
- Expense detail table (item, category, date, tag, total).
- Print stylesheet isolates `#reportPrintArea` for clean PDF export.

### 4. Booking Calendar (Admin + Staff)
- Month navigation (Prev/Next), legend for weekend/PH-holiday highlighting.
- Grid: rows = calendar dates, columns = Cabin 1–4 + Exclusive C. Cells show guest/status and a note preview; clicking a cell opens the Add/Edit Booking modal for that date+unit.
- "+ Add Booking" button opens a blank booking modal.
- **Add/Edit Booking modal**: unit checkboxes (Cabin 1-4, Exclusive A/B, Full Exclusive, Exclusive C), Source select, Package select, Check-in/Check-out date inputs, a per-night price breakdown list with a running Total, Guest name, Contact #, pax, deposit, balance, promo toggle (+ free-night date picker when applicable), notes, and status controls (mark no-show / cancelled+refund). Editable only if Admin or the booking's edit permission allows it.

### 5. Revenue Tracker (Admin only)
- Month navigation.
- Three cards, one per Exclusive (A/B/C): revenue, expenses (hover tooltip shows breakdown: direct, fixed-charged-direct, fixed general share, general expense share), net (color-coded green/red).
- Overall summary card: room revenue, misc revenue, total expenses (incl. fixed), projected profit.
- "Bookings this month" table with source filter chips.

### 6. Expense Tracker (Admin + Staff)
- Month navigation, "+ Add Expense" button.
- 4 summary cards (Exclusive A, B, C, General) each showing total incl. shared fixed costs, with hover tooltip breakdown.
- **Fixed monthly expenses** card — Admin only. Table: name, monthly amount, "Charged to" tag badge, Edit/Delete (Admin). "+ Add fixed expense" opens a modal with name, monthly amount, and a "Charged to" select (General / Exclusive A / B / C).
- **All expenses** table — filterable by tag chips (A/B/C/General). Columns: photo, item, category, cost, qty, total, date, exclusive tag (editable dropdown for Admin, badge for Staff), Edit/Delete actions (Edit gated by canEdit; Delete Admin-only). Staff see only their own entries.
- **Add/Edit Expense modal**: photo upload, item, category select, cost, quantity, date, exclusive tag select, notes.

### 7. Misc Revenue (Admin + Staff)
- Month filter, "+ Add Entry" button.
- Trend chart (implementation detail — check prototype for exact chart) and a type filter.
- Table: type, guest, amount, date, notes, logged by, Edit (everyone with access) / Delete (Admin only) actions.
- **Add/Edit modal**: type select (Land Tour/Massage/Food/Motor Rental), guest source toggle (pick existing booking guest vs type a name manually), amount, date, notes.

### 8. Admin Panel (Admin only)
- Table of staff accounts: name, username, role, "Can edit" (Yes/View only), Edit action.
- "+ Add Staff" opens a modal: name, username, password, "Can edit existing entries" checkbox.

## Design Tokens
The prototype uses the "Classical" design system: warm off-white background, near-black text, a single gold/bronze accent (~#b68235) with 100–900 tonal ramps, Cormorant Garamond for headings + Lora for body text, hairline dividers, outlined (not filled) buttons/cards, generous spacing. The sidebar nav uses a dark near-black background (`--color-neutral-900`) with the accent color for the active nav item. Pull exact hex/spacing/radius/shadow values from the linked `styles.css` referenced in the HTML file's `<head>`.

## Assets
- `assets/balay-logo.png` — Balay at Santa Fe logo, used on the login screen and sidebar header.
- Expense photos are drag-and-drop placeholders (`<image-slot>`) — no real images stored; wire up real upload/storage.

## Files included
- `Booking Revenue Expense Tracker.dc.html` — the full prototype (open in a browser to click through every screen and modal).
- `assets/` — logo and other static assets referenced by the prototype.
- `screenshots/` — reference screenshots of every screen (login, dashboard, booking calendar, reports, revenue tracker, expense tracker, misc revenue, admin panel), logged in as Admin.

## Deployment note
Once rebuilt with a real backend: `vercel deploy` (or connect the GitHub repo to Vercel for auto-deploys), set the database connection string and auth secrets as Vercel environment variables, and run database migrations as part of the build/deploy step.
